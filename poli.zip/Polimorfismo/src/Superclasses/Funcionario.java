
package Superclasses;

public class Funcionario {
    public void cadastrarFunc(){
        System.out.println("Funcionario cadastrado!");
         }
        public void excluirFunc(){
            System.out.println("Funcionario excluido");
}
   
    
}
