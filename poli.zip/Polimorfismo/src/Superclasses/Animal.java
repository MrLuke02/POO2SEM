
package Superclasses;

public class Animal {
    public void cadastrarAnimal(){
        System.out.println("Animal cadastrado");
    }
    
    public void excluirAnimal(){
        System.out.println("Animal excluido");
    }
    
}
