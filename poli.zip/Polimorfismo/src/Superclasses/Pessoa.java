
package Superclasses;

public class Pessoa {
    
    public void cadastrar(){
        System.out.println("Pessoa cadastrada!");
        
    }
    
    public void excluir(){
        System.out.println("Pessoa excluida");
    }
    
}
