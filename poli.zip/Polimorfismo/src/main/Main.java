
package main;

import Subclasses.Aluno;
import Subclasses.Cachorro;
import Subclasses.Gato;
import Subclasses.Macaco;
import Subclasses.Mae;
import Subclasses.Pai;
import Subclasses.Professor;
import Subclasses.Vigia;
import Subclasses.Zelador;

public class Main {
    public static void main(String[] args) {
    Aluno a1 = new Aluno();
    Mae mae = new Mae();
    Pai p1 = new Pai();
    Cachorro c1 = new Cachorro();
    Gato g1 = new Gato();
    Macaco m1 = new Macaco();
    Professor prof = new Professor();
    Vigia v1 = new Vigia();
    Zelador z1 = new Zelador();
    
    
    a1.cadastrar();
    a1.excluir(a1);
    
    mae.cadastrar();
    mae.excluir(mae);
    
    p1.cadastrar();
    p1.excluir(p1);
    
    c1.cadastrarAnimal();
    c1.excluirAnimal(c1);
    
    g1.cadastrarAnimal();
    g1.excluirAnimal(g1);
    
    m1.cadastrarAnimal();
    m1.excluirAnimal(m1);
    
    prof.cadastrarFunc();
    prof.excluirFunc(prof);
    
    v1.cadastrarFunc();
    v1.excluirFunc(v1);
    
    z1.cadastrarFunc();
    z1.excluirFunc(z1);
    }
    
}
