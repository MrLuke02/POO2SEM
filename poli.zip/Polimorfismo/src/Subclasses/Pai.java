
package Subclasses;

import Superclasses.Pessoa;

public class Pai extends Pessoa{
 @Override   
    public void cadastrar(){
       System.out.println("Pai cadastrado"); 
    }
    
    public void excluir(Pai pai){
        System.out.println("pai excluido");
    }
    
}
