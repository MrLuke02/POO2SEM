
package Subclasses;

import Superclasses.Animal;

public class Gato extends Animal{
    @Override
    public void cadastrarAnimal(){
        System.out.println("Gato cadastrado");
    }
    
    public void excluirAnimal(Gato gato){
        System.out.println("Gato excluido");
    }
    
}
