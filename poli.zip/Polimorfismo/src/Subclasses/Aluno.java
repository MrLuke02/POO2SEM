
package Subclasses;

import Superclasses.Pessoa;

public class Aluno extends Pessoa{
 @Override   
    public void cadastrar(){
       System.out.println("Aluno cadastrado"); 
    }
    
    public void excluir(Aluno aluno){
        System.out.println("Aluno excluido");
    }
    
    
}
