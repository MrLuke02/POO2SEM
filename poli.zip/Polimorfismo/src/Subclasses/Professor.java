
package Subclasses;

import Superclasses.Funcionario;

public class Professor extends Funcionario{
    @Override
   public void cadastrarFunc(){
        System.out.println("Professor cadastrado!");
         }
        public void excluirFunc(Professor professor){
            System.out.println("Professor excluido");
        }
    
}
