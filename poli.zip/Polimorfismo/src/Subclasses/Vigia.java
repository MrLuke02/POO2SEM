
package Subclasses;

import Superclasses.Funcionario;

public class Vigia extends Funcionario{
    
    @Override
   public void cadastrarFunc(){
        System.out.println("Vigia cadastrado!");
         }
        public void excluirFunc(Vigia vigia){
            System.out.println("Vigia excluido");
        }
    
    
}
