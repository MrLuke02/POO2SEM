
package Subclasses;

import Superclasses.Animal;

public class Macaco extends Animal{
    @Override
    public void cadastrarAnimal(){
        System.out.println("Macaco cadastrado");
    }
    
    public void excluirAnimal(Macaco macaco){
        System.out.println("Macaco excluido");
    }
    
}
