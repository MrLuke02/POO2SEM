
package Subclasses;

import Superclasses.Pessoa;

public class Mae extends Pessoa{
 @Override   
    public void cadastrar(){
       System.out.println("Mãe cadastrada"); 
    }
    
    public void excluir(Mae mae){
        System.out.println("Mãe excluida");
    }
    
}
