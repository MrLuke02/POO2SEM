
package Subclasses;

import Superclasses.Funcionario;

public class Zelador extends Funcionario{
    
    @Override
   public void cadastrarFunc(){
        System.out.println("Zelador cadastrado!");
         }
        public void excluirFunc(Zelador zelador){
            System.out.println("Zelador excluido");
        }
    
    
}
