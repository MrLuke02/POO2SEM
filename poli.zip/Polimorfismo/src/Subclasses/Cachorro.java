
package Subclasses;

import Superclasses.Animal;

public class Cachorro extends Animal{
    @Override
    public void cadastrarAnimal(){
        System.out.println("Cachorro cadastrado");
    }
    
    public void excluirAnimal(Cachorro cachorro){
        System.out.println("Cachorro excluido");
    }
    
}
