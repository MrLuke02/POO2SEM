package aluno;

public class AlunoMonitor extends Aluno{
    private double salario;
    private String disciplinaMonitor;

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public String getDisciplinaMonitor() {
        return disciplinaMonitor;
    }

    public void setDisciplinaMonitor(String disciplinaMonitor) {
        this.disciplinaMonitor = disciplinaMonitor;
    }
    
}
