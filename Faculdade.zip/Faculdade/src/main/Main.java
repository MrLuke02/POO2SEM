package main;

import aluno.AlunoEstagiario;
import aluno.AlunoMonitor;
import funcionario.Professor;
import funcionario.Recepcionista;

public class Main {
    public static void main(String[] args) {
        AlunoEstagiario ae = new AlunoEstagiario();
        AlunoMonitor am = new AlunoMonitor();
        
        Professor p = new Professor();
        Recepcionista r = new Recepcionista();
        
        
        
        ae.setCpf("735.569.110-43");
        ae.setCurriculo("Curso em Gestão da Tecnologia da Informação");
        ae.setNome("João");
        ae.setRg("46.366.427-9");
        ae.setSalario(998);
        
        am.setCpf("544.173.680-15");
        am.setDisciplinaMonitor("Programação orientada a objetos");
        am.setNome("João");
        am.setRg("34.493.417-2");
        am.setSalario(998);
        
        
        
        
        
        
        
    }
    
}
