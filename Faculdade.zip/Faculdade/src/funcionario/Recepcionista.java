package funcionario;

public class Recepcionista extends Funcionario{
    private String horario;
    
}
