package funcionario;

public class Professor extends Funcionario{
    private String disciplinaAplicada;

    public String getDisciplinaAplicada() {
        return disciplinaAplicada;
    }

    public void setDisciplinaAplicada(String disciplinaAplicada) {
        this.disciplinaAplicada = disciplinaAplicada;
    }

    public String getEnsinoAtuante() {
        return ensinoAtuante;
    }

    public void setEnsinoAtuante(String ensinoAtuante) {
        this.ensinoAtuante = ensinoAtuante;
    }
    private String ensinoAtuante;
    
}
