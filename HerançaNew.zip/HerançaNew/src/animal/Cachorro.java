package animal;

public class Cachorro extends Animal{
    
    public Cachorro(String cor, double peso){
        super(cor, peso); 
        
    }
    
    
}
