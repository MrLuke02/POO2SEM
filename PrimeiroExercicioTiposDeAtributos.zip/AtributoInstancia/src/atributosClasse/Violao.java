package atributosClasse;
public class Violao {
    public static String marca;
    public static String modelo;
    public static String qtdCordas;
    public static String conectividade;
    public static String captacao;
    
}
