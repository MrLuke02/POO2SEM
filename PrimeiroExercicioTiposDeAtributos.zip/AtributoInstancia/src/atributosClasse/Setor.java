package atributosClasse;
public class Setor {
    public static String empresa;
    public static String gerente;
    public static String idEmpresa;
    public static String pais;
    public static String estado;
    
}
