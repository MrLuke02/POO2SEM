package atributosClasse;
public class Main {
    public static void main(String[] args) {
        DadosProduto.anoProducao = "2019";
        DadosProduto.areaProducao = "Zona franca de Manaus";
        DadosProduto.cnpj = "51.270.064/0001-43";
        DadosProduto.codigoEmpresa = "5234687";
        DadosProduto.marca = "Goldentec"; 
        
        System.out.println(DadosProduto.anoProducao);
        System.out.println(DadosProduto.areaProducao);
        System.out.println(DadosProduto.cnpj);
        System.out.println(DadosProduto.codigoEmpresa);
        System.out.println(DadosProduto.marca);
    }
    
}
