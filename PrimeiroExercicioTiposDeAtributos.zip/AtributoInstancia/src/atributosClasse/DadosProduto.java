package atributosClasse;
public class DadosProduto {
    public static String marca;
    public static String cnpj;
    public static String codigoEmpresa;
    public static String areaProducao;
    public static String anoProducao;
    
}
