package atributosClasse;
public class DadosAluno {
    public static String instituicao;
    public static String nacionalidade;
    public static String estado;
    public static String municipio;
    public static String bairro;
    
}
