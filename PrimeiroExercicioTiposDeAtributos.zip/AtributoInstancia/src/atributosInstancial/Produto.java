
package atributosInstancial;
public class Produto {
    public String nome;
    public String lote;
    public String dataFabricacao;
    public String codigo;
    public String dataChegada;
    
}
