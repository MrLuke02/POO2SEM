package atributosInstancial;
public class Computador {
    public String processador;
    public double qtdRam;
    public double armazenamento;
    public String processadorGrafico;
    public double gtdVRam;
    
}
