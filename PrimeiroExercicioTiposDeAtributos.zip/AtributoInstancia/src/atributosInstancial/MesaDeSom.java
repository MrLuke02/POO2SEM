package atributosInstancial;
public class MesaDeSom {
    public String modelo;
    public String qtdCanais;
    public String qtdBus;
    public String qtdXlr;
    public String qtdEfeitos;
    
}
