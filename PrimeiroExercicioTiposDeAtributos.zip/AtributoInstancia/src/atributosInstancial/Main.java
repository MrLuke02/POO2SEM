
package atributosInstancial;

public class Main {
    public static void main(String[] args) {
        Pessoa p1 = new Pessoa();
        p1.cpf = "910.152.990-08";
        p1.dataNascimento = "23/12/1990";
        p1.nome = "José";
        p1.rg = "27.294.530-4";
        p1.sexo = true;
        
        
        Pessoa p2 = new Pessoa();
        p2.cpf = "665.281.480-31";
        p2.dataNascimento = "04/03/1997";
        p2.nome = "Maria";
        p2.rg = "50.720.323-9";
        p2.sexo = false;
        
        
        System.out.println(p1.cpf);
        System.out.println(p1.dataNascimento);
        System.out.println(p1.nome);
        System.out.println(p1.rg);
        if(p1.sexo == true){
            System.out.println("Homem");
        }else{
            System.out.println("Mulher");
            
        }
        
        
        System.out.println("");
        System.out.println("");
        
        
        
        System.out.println(p2.cpf);
        System.out.println(p2.dataNascimento);
        System.out.println(p2.nome);
        System.out.println(p2.rg);
        if(p2.sexo == true){
            System.out.println("Homem");
        }else{
            System.out.println("Mulher");
        }
        
        
        
    }
    
}
