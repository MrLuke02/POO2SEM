
package atributosInstancial;

public class Pessoa {
    public String nome;
    public boolean sexo;
    public String dataNascimento;
    public String cpf;
    public String rg;
    
}
