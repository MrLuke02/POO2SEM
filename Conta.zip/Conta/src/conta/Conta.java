package conta;
public class Conta {
    public String numeroAgencia;
    public String  numeroConta;
    public double saldo;
    
    public static void depositar(Conta c1, double valor){
        if(valor > 0 && c1 != null){
            c1.saldo += valor;
            System.out.println("Deposito realizado");
            System.out.println("Novo saldo: " + c1.saldo);
            System.out.println("");
        }
    }
    
    
    public void transferir(Conta contaDestino, double valor){
        if(this.saldo >= valor && contaDestino != null){
            this.saldo = this.saldo - valor;
            contaDestino.saldo += valor;
            System.out.println("Transferência realizado");
            System.out.println("Novo saldo: " + this.saldo);
            System.out.println("");
        }
    }
    
}
