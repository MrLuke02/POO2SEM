package main;

import pacote.AlunoPacote;
import privado.AlunoPrivado;
import protegido.AlunoProtegido;
import publico.AlunoPublico;

public class Main {
    public static void main(String[] args) {
        AlunoPacote a1 = new AlunoPacote();
        AlunoPrivado a2 = new AlunoPrivado();
        AlunoProtegido a3 = new AlunoProtegido();
        AlunoPublico a4 = new AlunoPublico();
        
        a1.setNome("Davy");
        a2.setNome("Davydson");
        a3.setNome("Dyva");
        a4.nome = "Yvad";
        
        System.out.println(a1.getNome());
        System.out.println(a2.getNome());
        System.out.println(a3.getNome());
        System.out.println(a4.getNome());
    }
    
}
