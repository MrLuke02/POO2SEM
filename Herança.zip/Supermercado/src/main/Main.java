package main;

import produto.Arroz;
import produto.Bombril;
import produto.LeiteCondensado;

public class Main {
    public static void main(String[] args) {
        Arroz a = new Arroz();
        Bombril b = new Bombril();
        LeiteCondensado l = new LeiteCondensado();
        
        a.setNomeProduto("Panelaço");
        b.setNomeProduto("Assolan");
        l.setNomeProduto("Italac");
        
        System.out.println(a.getNomeProduto());
        System.out.println(b.getNomeProduto());
        System.out.println(l.getNomeProduto());
        
    }
    
}
