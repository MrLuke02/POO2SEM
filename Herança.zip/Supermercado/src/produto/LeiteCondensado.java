package produto;
public class LeiteCondensado extends Produto{
    
}
