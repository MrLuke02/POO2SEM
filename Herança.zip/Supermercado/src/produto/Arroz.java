package produto;
public class Arroz extends Produto{
    
    
}
