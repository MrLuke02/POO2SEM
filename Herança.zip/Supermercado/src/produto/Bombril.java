package produto;
public class Bombril extends Produto{
    
    
}
