package protegidos;

import publicos.*;

public class Mouse {
    protected String modelo;
    protected String marca;
    protected boolean rgb;
    protected String dpi;
    protected String usb;
    
}
