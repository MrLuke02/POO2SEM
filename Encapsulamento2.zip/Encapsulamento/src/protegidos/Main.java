package protegidos;

import publicos.*;

public class Main {
    public static void main(String[] args) {
        Som s1 = new Som();
        
        s1.marca = "Philips";
        s1.modelo = "SC-AKX100LBK";
        s1.potenciaPmpo = "25002";
        s1.potenciaRms = "2502";
        s1.qtdCaixas = "2";
        
        Fone f1 = new Fone();
        
        f1.cor = "Preto";
        f1.fio = true;
        f1.marca = "Razer";
        f1.modelo = "Kraken";
        f1.potencia = "30 mW";
        
        Mouse m1 = new Mouse();
        m1.dpi = "3200";
        m1.marca = "HyperX";
        m1.modelo = "HX-MC001A/AM";
        m1.rgb = true;
        m1.usb = "3.0";
        
        Interface i1 = new Interface();
         
        i1.marca = "Behringer";
        i1.modelo = "UMC404HD";
        i1.qtdSaidas = "4";
        i1.qtdEntradas = "4";
        i1.preAmp = true;
         
        Celular c1 = new Celular();
        
        c1.cor = "Preto";
        c1.marca = "Samsung";
        c1.memoriaInterna = "128gb";
        c1.modelo = "S10e Duos";
        c1.ram = "6gb";
        
        System.out.println(s1.marca);
        System.out.println(s1.modelo);
        System.out.println(s1.potenciaPmpo);
        System.out.println(s1.potenciaRms);
        System.out.println(s1.qtdCaixas);
        System.out.println("");
         
        System.out.println(f1.cor);
        System.out.println(f1.fio);
        System.out.println(f1.marca);
        System.out.println(f1.modelo);
        System.out.println(f1.potencia);
        System.out.println("");
         
        System.out.println(m1.dpi);
        System.out.println(m1.marca);
        System.out.println(m1.modelo);
        System.out.println(m1.rgb);
        System.out.println(m1.usb);
        System.out.println("");
        
        System.out.println(i1.modelo);
        System.out.println(i1.marca);
        System.out.println(i1.preAmp);
        System.out.println(i1.qtdEntradas);
        System.out.println(i1.qtdSaidas);
        System.out.println("");
        
        System.out.println(c1.cor);
        System.out.println(c1.marca);
        System.out.println(c1.memoriaInterna);
        System.out.println(c1.modelo);
        System.out.println(c1.ram);
         
    }
    
}
