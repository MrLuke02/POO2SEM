package protegidos;

import publicos.*;

public class Fone {
    protected String marca;
    protected String potencia;
    protected String modelo;
    protected String cor;
    protected Boolean fio;
    
}
