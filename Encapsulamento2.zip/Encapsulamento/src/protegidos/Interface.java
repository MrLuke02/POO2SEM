package protegidos;

import publicos.*;

public class Interface {
protected String modelo;
protected String marca;
protected String qtdEntradas;
protected boolean preAmp;
protected String qtdSaidas;
}
