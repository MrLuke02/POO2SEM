package protegidos;

import publicos.*;

public class Som {
    protected String marca;
    protected String modelo;
    protected String potenciaPmpo;
    protected String potenciaRms;
    protected String qtdCaixas;
    
}
