package protegidos;

import publicos.*;

public class Celular {
    protected String modelo;
    protected String marca;
    protected String memoriaInterna;
    protected String ram;
    protected String cor;
    
}
