package publicos;
public class Carro {
    String marca;
    String modelo;
    String rodas;
    boolean arCondicionado;
    String motor;
    
}
