package publicos;
public class Computador {
    String cpu;
    String gpu;
    int ram;
    String fonte;
    int armazenamento;
    
}
