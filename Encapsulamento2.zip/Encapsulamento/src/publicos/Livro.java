package publicos;
public class Livro {
    String titulo;
    String autor;
    String codigo;
    String distribuidora;
    String edicao;
    
}
