package publicos;
public class Produto {
    String id;
    String nome;
    String marca;
    String lote;
    String fabricacao;
    
}
