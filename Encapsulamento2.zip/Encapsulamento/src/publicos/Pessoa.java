package publicos;
public class Pessoa {
String nome;
String cpf;
String rg;
String nacionalidade;
String dataNascimento;
}
