package publicos;
public class Main {
    public static void main(String[] args) {
        Carro c1 = new Carro();
        
        c1.arCondicionado = true;
        c1.marca = "Volkswagen";
        c1.modelo = "Golf";
        c1.motor = "2.0";
        c1.rodas = "17'' ";
        
        Computador pc1 = new Computador();
        
        pc1.armazenamento = 1000;
        pc1.cpu = "I5 3570";
        pc1.fonte = "430w";
        pc1.gpu = "GTX950";
        pc1.ram = 8000;
        
        Livro l1 = new Livro();
        l1.autor = "Machado de assis";
        l1.codigo = "324654";
        l1.distribuidora = "Penguin";
        l1.edicao = "1°";
        l1.titulo = "O Alienista";
        
        Pessoa p1 = new Pessoa();
         
        p1.cpf = "354.745.934-65";
        p1.dataNascimento = "12/03/1998";
        p1.nacionalidade = "Brasileiro";
        p1.nome = "João";
        p1.rg = "48.351.662-4";
         
        Produto pr1 = new Produto();
        
        pr1.fabricacao = "05/12/2018";
        pr1.id = "6213451";
        pr1.lote = "5432453.67";
        pr1.marca = "Razer";
        pr1.nome = "Deathadder";
        
        System.out.println(c1.arCondicionado);
        System.out.println(c1.marca);
        System.out.println(c1.modelo);
        System.out.println(c1.motor);
        System.out.println(c1.rodas);
        System.out.println("");
         
        System.out.println(pc1.armazenamento);
        System.out.println(pc1.cpu);
        System.out.println(pc1.fonte);
        System.out.println(pc1.gpu);
        System.out.println(pc1.ram);
        System.out.println("");
         
        System.out.println(l1.autor);
        System.out.println(l1.codigo);
        System.out.println(l1.distribuidora);
        System.out.println(l1.edicao);
        System.out.println(l1.titulo);
        System.out.println("");
        
        System.out.println(p1.cpf);
        System.out.println(p1.dataNascimento);
        System.out.println(p1.nacionalidade);
        System.out.println(p1.nome);
        System.out.println(p1.rg);
        System.out.println("");
        
        System.out.println(pr1.fabricacao);
        System.out.println(pr1.id);
        System.out.println(pr1.lote);
        System.out.println(pr1.marca);
        System.out.println(pr1.nome);
         
    }
    
}
