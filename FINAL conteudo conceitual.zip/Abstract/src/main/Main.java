
package main;

import funcionário.Funcionario;
import funcionário.Gerente;
import funcionário.Secretaria;
import funcionário.ServicoGerais;

public class Main {
    
    public static void calcularBonificacao(Funcionario f){
f.bonificacao();

if(f instanceof Gerente){
    System.out.println("Gerente: " + (f.getSalario() + f.getBonificacao()));    
}else if(f instanceof Secretaria){
    System.out.println("Secretaria: " + (f.getSalario() + f.getBonificacao()));
}else{
    System.out.println("S. Gerais: " + (f.getSalario() + f.getBonificacao()));
}
        
    }
    
    
    public static void main(String[] args) {
        Gerente g = new Gerente();
        Secretaria s = new Secretaria();
        ServicoGerais sg = new ServicoGerais();
        
        g.setSalario(1000);
        s.setSalario(1000);
        sg.setSalario(1000);
        
           
        calcularBonificacao(s);
        calcularBonificacao(g);
        calcularBonificacao(sg);
        
        System.out.println(g.getSalario());
        System.out.println(s.getSalario());
        System.out.println(sg.getSalario());
     
        
    }
    
}
